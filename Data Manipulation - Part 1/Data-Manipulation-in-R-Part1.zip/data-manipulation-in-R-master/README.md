# Data-manipulation-in-R (Part 1)

The tutorial covers:

Introduction to data types in R

Setting working environment in R

Installing packages in R

Reading in data in R

Exploring data structure

Data manipulation using dplyr Verbs; mutate, filter, group_by,summarise,arrange, select, rename 

Piping
